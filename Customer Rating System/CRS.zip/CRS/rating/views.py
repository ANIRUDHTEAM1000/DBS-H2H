from django.http.response import Http404
from django.shortcuts import render
from django.http import HttpResponse
from .models import Transactions
from .models import Rules
from .models import Account_info
from .models import Customer_info
from .models import Countries
import datetime
# Create your views here.
def rating(request):
   return render(request,'index.html')
 

def output(request):
   rules=list(Rules.objects.all().filter(applied=True))
   temp=Account_info.objects.all().filter(account_key='CASP_D04050165300009')
   print(temp)
   print(len(Transactions.objects.filter(acc_key='CASP_D04050165300009')))
   a=Transactions.objects.filter(acc_key='CASP_D04050165300009')
   customers = Customer_info.objects.all();
   Residential_Country=None
   Risk_Rating=None
   Risk_Rating_Reason=None
   return render(request,'output.html',{'Customer_Name':customers[0].partykey,'Residential_Country':(customers[0].resident_country).rel_key,Risk_Rating:'','Risk_Rating_Reason':''})